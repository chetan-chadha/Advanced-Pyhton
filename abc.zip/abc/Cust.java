package abc;

public class Cust {
	
		 int id;
		 String name;
		 String email;
		 Cust(int id, String name, String email)
		 {
		   this.id = id;
		   this.name = name;
		   this.email = email;
		 }

}
