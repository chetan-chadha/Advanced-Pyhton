package abc;

public class Check_2 {
//solution 1
	
	public static void main(String args[]) {
		Cust e1 = new Cust(1, "Ram", "abc@gmail.com"); 
	    Cust e2 = new Cust(2, "Sam", "xyz@gmail.com");
	    boolean r = checkmail(e1, e2, "gmail.com");
	    System.out.println(r);
	  }
	  public static boolean checkmail(Cust e1, Cust e2, String domain)
	  {
	    String s1 = (e1.email).substring((e1.email).indexOf('@')+1);
	    String s2 = (e2.email).substring((e2.email).indexOf('@')+1);
	    if(s1.equals(domain) && s2.equals(domain))
	      return true;
	    else
	      return false;
	}
}
