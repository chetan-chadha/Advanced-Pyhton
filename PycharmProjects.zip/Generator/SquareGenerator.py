
def gen(limit):
    for y in range(limit):
        if y*y < limit:
            yield y
        else:
            break

lst = []
for num in gen(30):
    print(num,end = " ")
    lst.append(num)
