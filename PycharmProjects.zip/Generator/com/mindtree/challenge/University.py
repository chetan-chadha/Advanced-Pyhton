from com.mindtree.challenge.College import College
class University():
    __id = int()
    __name = ""
    __rating = int()
    __college_count = int()

    def __init__(self, id, name, rating, college_count):
        self.id = id
        self.name = name
        self.rating = rating
        self.colleges = list()
        self.colleges_count = college_count
        self.college_array(self.colleges_count)

    @property
    def id(self):
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def rating(self):
        return self.__rating

    @rating.setter
    def rating(self, value):
        self.__rating = value

    @property
    def colleges_count(self):
        return self.__college_count

    @colleges_count.setter
    def colleges_count(self, value):
        self.__college_count = value


    def college_array(self,value):
        for x in range(value):
            print("Enter College",x+1," details")
            id = int(input("Enter College ID"))
            name = input("Enter College Name")
            rating = int(input("Enter Ratings of College"))
            branch = list(input("Enter Branches Seprated by Space").split())
            self.colleges.append(College(id,name,rating,branch))
