from com.mindtree.challenge.University import University
def college_branch(university,name,count = 0):
    for x in university:
        for y in x.colleges:
            if y.name == name:
                count = 1
                return y.branch
    if count == 0:
        return "No College Found"
def check_branch(university,name,college,count = 0,count1 = 0):
    for x in university:
        for y in x.colleges:
            if college == y.name:
                count1 = 1
                if name in y.branch:
                    count = 1
                    return True
    if count1 == 0:
        print("No such College")
    if count == 0:
        return False
def max_college(university):
    max = 0
    for x in university:
        if int(x.colleges_count)>max:
            max = x.colleges_count
            print(max)
    for x in university:
        if int(x.colleges_count) == max:
            print(x.name)
def university_college(university,uni_name,count = 0):
    for x in university:
        if x.name == uni_name:
            count = 1
            for y in x.colleges:
                print(y.id,y.name,y.rating,y.branch)
    if count == 0:
        print("NO such University")


def input_data():
    university = []
    count = int(input("Enter No of Universities"))
    for x in range(count):
        print("Enter University",x+1,"details")
        id = int(input("Enter ID"))
        name = input("Enter Name")
        rating = int(input("Enter Rating"))
        college_count = int(input("Enter No of Colleges in This university"))
        university.append(University(id,name,rating,college_count))
    return university
def main():
    university = input_data()
    uni_arr = []
    uni_arr.append(University(12,))
    while True:
        Enter_Case = int(input("Enter Case"))
        if Enter_Case == 1:
            collge_name = input("Enter COllege Name")
            branches = college_branch(university,collge_name)
            print(branches)
            continue

        elif Enter_Case == 2:
            uni_name = input("Enter Uni for searching")
            university_college(university,uni_name)
            continue

        elif Enter_Case == 3:
            branch_name = input("Enter Branch")
            college = input("Enter College Name")
            value = check_branch(university,branch_name,college)
            print(value)
            continue

        elif Enter_Case == 4:
            max_college(university)
            continue

        else:
            print("I am Exiting")
            break
main()