class College():
    __id = int()
    __name = ""
    __rating = int()
    __branches = list()
    def __init__(self,id,name,rating,branch):
      self.id = id
      self.name = name
      self.rating = rating
      self.branch = branch

    @property
    def id(self):
        return self.__id
    @id.setter
    def id(self,value):
        self.__id = value

    @property
    def name(self):
        return self.__name
    @name.setter
    def name(self,value):
        self.__name = value

    @property
    def rating(self):
        return self.__rating
    @rating.setter
    def rating(self,value):
        self.__rating = value

    @property
    def branch(self):
        return self.__branches
    @branch.setter
    def branch(self,value):
        self.__branches = value