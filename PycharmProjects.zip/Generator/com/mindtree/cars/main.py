from com.mindtree.cars.car_accesories import Car
from threading import Thread
from time import sleep
def object_creator(lst):
    c1 = list()
    for i in lst:
        wheel,battery,speed = i
        c1.append(Car(wheel,battery,speed))
    return c1
arguments = [["Polo","Exide",2],["TVS","BAJAJ",3]]
lst = object_creator(arguments)
def object_caller(obj):
    for i in obj:
        print(i,"Kmph")
        sleep(.2)

t1 = Thread(target=object_caller,args=(lst[0],))
t2 = Thread(target=object_caller,args=(lst[1],))
t1.start()
t2.start()
