class Car():
    __wheel_brand = ""
    __battery_brand = ""
    __speed = int()
    def __init__(self,wheel = "MRF",battery = "Amaron",speed = 0):
        self.battery_brand  = battery
        self.wheel_brand = wheel
        self.speed = speed
    def __iter__(self):
        return self
    def __next__(self):
        if 100<self.speed:
            raise StopIteration
        self.speed = self.speed +1
        return self.speed-1


    @property
    def battery_brand(self):
        return self.__battery_brand
    @battery_brand.setter
    def battery_brand(self,value):
        self.__battery_brand = value
    @property
    def wheel_brand(self):
        return self.__wheel_brand

    @wheel_brand.setter
    def wheel_brand(self, value):
        self.__wheel_brand = value

    @property
    def speed(self):
        return self.__speed

    @speed.setter
    def speed(self, value):
        self.__speed = value


print([x for x in Car()])