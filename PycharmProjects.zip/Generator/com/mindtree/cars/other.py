dic = {'one_dict':{3:"You Got Me"},'two_dict':(3,4,5)}
print(dic['one_dict'][3],dic['two_dict'][1])
lst1 = list()
lst2 = list()
# for i in dic:
#     lst1.append(i)
#     if type(dic[i]) == dict:
#         for x in dic[i]:
#             lst1.append(x)
#             lst2.append(dic[i][x])
#     else:
#         lst2.append(dic[i])
lst1 = list(dic.keys())
lst2 = list(dic.values())
print(lst1)
print(lst2)
print(dic.items())