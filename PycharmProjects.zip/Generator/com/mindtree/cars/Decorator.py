def deco(sum):
    def helper(a,b):
        print("hello i am deco")
        sum(a,b)
        print("Helo in am deco")
    return helper

def sum(a,b):
    print(a+b)
sum  = deco(sum)
sum(1,2)