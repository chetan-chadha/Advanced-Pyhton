from com.mindtree.clock.class_clock import Clock
from threading import Thread
from threading import Lock
from time import sleep
lock = Lock()
class Alarm(Clock):
    def __init__(self,hour,min,second):
        Clock.__init__(self,hour,min,second)
def foo(lock, value):
    lock.acquire()
    print("I am locked")
    try:
    # only one thread can execute code there
       value.start_clock()
    finally:
        lock.release()  # release lock
        print("i am released")
alarm_arr = list()
t = list()
lst = [[1,2,3],[3,4,5],[5,6,7],[8,6,7],[10,4,3],[4,5,6],[2,3,4],[4,2,3],[12,4,5],[12,4,5]]
# for x in range(3):
#     hour,min,second = lst[x]
#     alarm_arr.append(Alarm(hour,min,second))
#     t.append(Thread(target=foo,args=(lock,alarm_arr[x])))

for x in range(3):
    t[x].start()
    sleep(.2)


