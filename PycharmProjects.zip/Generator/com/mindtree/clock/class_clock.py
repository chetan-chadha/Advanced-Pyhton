import time
import threading
class Clock():
    __hour = int()
    __min = int()
    __sec = int()
    def __init__(self,hour = 12,minute = 0,second = 0):
        self.lock = threading.Lock()
        self.h1 = hour
        self.m1 = minute
        self.s1 = second
        self.hours = list(range(0,24))
        self.minutes = list(range(0,60))
        self.seconds = list(range(0,60))

    def start_clock(self):
        i = self.s1
        j = self.h1
        k = self.m1
        while True:
            print(self.hours[j],":","%02d"%self.minutes[k],":",self.seconds[i])
            print(" ")
            time.sleep(.2)
            if i+1 == 60:
                k = k+1
                break
            if k+1 == 60:
                j = j+1
            i = (i+1) % 60
    @property
    def hours(self):
        return self.__hour
    @hours.setter
    def hours(self,value):
        self.__hour = value

    @property
    def minutes(self):
        return self.__min
    @minutes.setter
    def minutes(self,value):
        self.__min = value

    @property
    def seconds(self):
        return self.__sec
    @seconds.setter
    def seconds(self,value):
        self.__sec = value

c1 = Clock()
c1.hours = 8
print(c1.hours)