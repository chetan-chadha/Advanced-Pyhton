from sys import argv
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("First File", help="Enter First File Name",
                    type=str)
parser.add_argument("Second File",help = "Enter Second File Name")
# args = parser.parse_args()
# print(args.square**2)
parser.parse_args()
def take_argv(argv1, argv2):
    """
    This function take 2 arguments from the cmd
    :param argv1: first file name
    :param argv2: second file name
    :return: integer
    """
    try:
        file1 = open(argv1,'r')
        file2 = open(argv2,'r')
    except:
        exec(open("python_help_examples.py").read())
        print("Please pass 2 correct file Names")
if len(argv)<3:
    print("Please Enter Correct Parameters")
else:
    file1 = argv[1]
    file2 = argv[2]
    take_argv(file1,file2)

