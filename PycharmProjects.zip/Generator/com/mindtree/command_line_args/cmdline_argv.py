from sys import argv
def open_file():
    """This is help for command line arguments\n It take input from the user"""

open_file()
if "-h" in argv or "--help" in argv:
    print(help(open_file))
    # print("this is a pyhton program to take COmmand line inputs \n It take 2 parameters first file name second file name")
