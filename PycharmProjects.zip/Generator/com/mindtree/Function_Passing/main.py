def print_num(x):
    print(x)

def printing(fun):
    for x in range(10,0,-1):
        fun(x)


printing(print_num)


