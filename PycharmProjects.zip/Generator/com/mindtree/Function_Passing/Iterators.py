string = "Welcome To Possible"
lst = [x for x in string if x != " "]
print(lst)

def gen(string):
    for x in string:
        yield x


for x in gen(string):
    print(x)
print("\n\n")

class Counter1():
    def __init__(self,value):
        self.limit = value

    def __iter__(self):
        self.num = 0
        return self
    def next(self):
        x = self.limit
        if self.limit<self.num+1:
            raise StopIteration
        self.num = self.num+1

        return self.num-1

for x in Counter1(10):
    print(x)

def sample_fun():
    print("FIrst")
    yield 1
    print("second")
    yield 2

for x in sample_fun():
    print(x)