# def smart_divide(func):
# #    def inner(a,b):
# #       print("I am going to divide",a,"and",b)
# #       if b == 0:
# #          print("Whoops! cannot divide")
# #          return
# #
# #       return func(a,b)
# #    return inner
# #
# # @smart_divide
# # def divide(a,b):
# #     print("I enter in divide")
# #     return a/b
# # print("I am here")
# # print(divide(2,3))

def memoize(f):
    memo = {}
    def helper(x):
        if x not in memo:
            print(x)
            memo[x] = f(x)
        return memo[x]
    return helper

def fib(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:

        return fib(n - 1) + fib(n - 2)

fib = memoize(fib)

print(fib(40))
