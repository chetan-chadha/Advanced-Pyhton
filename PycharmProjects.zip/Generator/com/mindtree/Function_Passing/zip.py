x = (1,2,3)
y = (4,5,6)
p = (7,8,9)
z = [x for x in zip(list(x),list(y),list(p))]
k = set(zip(x,y,p))
print(z,type(x))
print(k)