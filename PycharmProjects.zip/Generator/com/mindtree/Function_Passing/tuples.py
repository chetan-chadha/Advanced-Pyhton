from collections import Counter
tup = (1,2,1,3,2,4,5,5,4)
counter = Counter(x for x in tup)
counter = dict(counter)
# for x in counter:
#     if counter[x] >1:
#         print(x,end=" ")

dic1 = {1:4,6:4,7:5}
for x in dic1:
    counter[x] = dic1[x]
print(counter)
z = {**counter,**dic1}
print(z)
print(set(tup))
print(help(tuple))
# print(" ")
# print(len(tup))
# print(tup[2:4])

