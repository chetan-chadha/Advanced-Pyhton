dict = {}
min = 3;
for x in [1,2,3,4,1,1,3]:
    if x < min:
        min = x
    if x in dict:
        dict[x] = dict[x] + 1
    else:
        dict.update({x:1})
print(dict)
print("Unlucky" if dict[min]%2 == 0 else "Lucky")