def main():
    size = int(input())
    array = list(map(int,input().split(" ")))
    testcases = int(input())
    for x in range(testcases+1) :
        test = int(input())
        count = 0
        print(test)
        for x in array:
            if x == test:
                count +=  1
        print("hy")
        if count > 0:
            print(count)
        else:
            print("NOT PRESENT")
            continue
if __name__ == '__main__':
    main()