def remove_values_from_list(the_list, val):
   return [value for value in the_list if value != val]
def main():
    # count = int(input())
    array = list(map(int,input().split()))
    dict = {}
    print(array)
    for x in array:
        if x in dict:
            dict[x] = dict[x] + 1
        else:
            dict.update({x: 1})
    array1 = list()

    array.sort()
    count = 1
    while count !=0:
        for x in range(1,len(array)):
            count = 0
            print("value of",x)
            if array[x]>array[x-1] and dict[array[x]]> 0:
                array[x-1] = 0
                dict[array[x]] = dict[array[x]] - 1;
                print(array)
                count = 1
            else:

                continue
        array = remove_values_from_list(array,0)
    print(array,dict)



main()