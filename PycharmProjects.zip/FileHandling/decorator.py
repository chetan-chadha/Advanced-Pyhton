def decorator(fun):
    def helper():
        num1 = int(input("Enter First"))
        num2 = int(input("Enter Second"))
        fun(num2,num1)
    return helper

@decorator
def sum(num1,num2):
    print(num1+num2)
@decorator
def subtract(num1,num2):
    print(abs(num2-num1))

subtract()
sum()