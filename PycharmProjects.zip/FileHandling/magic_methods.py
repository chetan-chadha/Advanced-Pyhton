class First():
    def __init__(self,value):
        self.value = value
    def __mul__(self,other):
        return self.value*other
    def __str__(self):
        return str(self.value + 12)
    def __add__(self, other):
        return self.value + other.value
    def __repr__(self):
        return 'Rational(%s)' % (self.value)
    def __gt__(self, other):
        if self.value>other:
            return True
        else:
            return False
class Second():
    def __init__(self,value):
        self.value = value
    def __add__(self,other):
        return self.value + other

c = First(9)
c1 = First(4)
print(c1)
print(repr(c))
print(c*5)
print(c>4)