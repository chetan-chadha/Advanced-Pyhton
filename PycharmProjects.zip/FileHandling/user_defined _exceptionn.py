class Numerical_Error(Exception):
    def __init__(self,value):
        self.msg = str(value)
    def __str__(self):
        return self.msg + " This Value is not Valid"

def main():
    num = int(input('Enter Number'))
    try:
        if num>25 and num<75 :
            raise Numerical_Error(num)
        else:
            print(num)
    except Numerical_Error as NE:
        print(NE)



if __name__ == '__main__':
    main()
