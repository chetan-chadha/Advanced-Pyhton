


remainder = lambda x,y : x%y
print(remainder(5,3))

from functools import reduce
# use anonymous function to filter and comparing
# if divisible or not
my_list = [x for x in range(10)]
square = lambda x: x*x
triple = lambda x: x*x*x
print(map(list,zip(map(square, my_list),map(triple,my_list))))
squareNum = list(map(square,my_list))
triplenum = list(map(triple,my_list))
print(map(square,my_list))
result1 = list(map(list,zip(squareNum,triplenum)))
print(squareNum)
print(triplenum)
print(result1)
# print(squareNum)
# a = list((5,6))
#
# print(a)
# # printing the result
# # result = list(filter((lambda x: (x%6==0)), my_list))
#
# print(result)