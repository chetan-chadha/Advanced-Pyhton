def main():
    dic = dict()
    while True:
        num1 = int(input("Enter First Number"))
        num2 = int(input("Enter Second Number"))
        if ((num1,num2)) in dic :
            print(dic[num1,num2])
        elif ((num2,num1)) in dic:
            print(dic[num2,num1])
        else:
            dic[num2,num1] = num2*num1
            print(dic[num2,num1])
        flag = input("Wna Stop Enter e")
        if flag == 'e':
            break
        else:
            continue



if __name__ == '__main__':
    main()