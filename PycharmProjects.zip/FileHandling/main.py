# file1 = open('File1.txt','r')
file2 = open('File2.txt','a+')
file1 = open('File1.txt','r')
read = file1.readlines()
for x,y in enumerate(read):
    if x == 2:
        for x in range(3):
            if "\n" in y:
                file2.write(y)
            else:
                file2.write(y+"\n")
    else:
        file2.write(y)
