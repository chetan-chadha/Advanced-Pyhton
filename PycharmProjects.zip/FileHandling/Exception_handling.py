def main():
    flag = 1
    file_name = 'File.txt'
    while flag ==1:
        try:
            file1 = open(file_name,'r')
        except FileNotFoundError as e:
            print()
            flag =1
            file_name = input("Enter Correct Name")
        else:
            flag = 0
    print(file1.read())
if __name__ == '__main__':
    main()