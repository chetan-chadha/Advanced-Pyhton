class Searching():
    def __init__(self,array):
        self.array = array
        self.found = 0
        self.index = None

    def sequential_search(self,val):
        for x in range(len(self.array)):
            if self.array[x] == val:
                self.found = 1
                self.index = x
                break
        if self.found == 1:
            return True,self.index
        else:
            return False,self.index
    def binary_serach(self,val):
        first = 0
        last = len(self.array)
        while first<last:
            mid = (first + last) // 2
            if self.array[mid] == val:
                self.found = 1
                self.index = mid
                break
            else:
                if val < self.array[mid]:
                    last = mid - 1
                elif val > self.array[mid]:
                    first = mid+1
        if self.found == 1:
            return True,self.index
        else:
            return False,self.index

arr = [1,5,2,3,7,66,4,34,6]
s1 = Searching(sorted(arr))
result,index = s1.sequential_search(3)
print(result,index)
s1 = Searching(arr)
result,index = s1.binary_serach(96)
print(result,index)


