import array
class Sorting:
    def __init__(self):
        print("hello",end = " ")


    def bubble_sort(self,array,length):
        for x in range(length-1,0,-1):
            for y in range(x):
                if array[y]>array[y+1]:
                    array[y+1],array[y] = array[y],array[y+1]
        return array

    def bubble_sort_recurrsion(self,array,length):
        if length>0:
            for y in range(length-1):
                if array[y] > array[y + 1]:
                    array[y + 1], array[y] = array[y], array[y + 1]
            return self.bubble_sort_recurrsion(array,length-1)
        else:
            return array

ar = array.array('i',[1,2,5,3,12,4,56,2])
print(type(ar))
arr = array.array('i', [1, 2, 3])
ar[2] = 10
# printing original array
print("The new created array is : ", end=" ")
# for i in range(0, 6):
#     print(ar[i], end=" ")
s1 = Sorting()
ar = s1.bubble_sort_recurrsion(ar,8)
for i in range(8):
    print(ar[i],end = " ")