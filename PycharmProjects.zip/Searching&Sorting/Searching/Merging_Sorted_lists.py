l1 = [1,3,4,5,10,16,19]
l2 = [2,6,7,8,9,13,15]
i = 0
j = 0
k = 0
l3 = [0] * (len(l1) + len(l2))
while i < len(l1) and j < len(l2):
    if l1[i]<l2[j]:
        l3[k] = l1[i]
        i = i+1
        k = k+1
    else:
        l3[k] = l2[j]
        j = j+1
        k = k+1

while i < len(l1):
    l3[k] = l1[i]
    k = k +1
    i = i+1
while j <len(l2):
    l3[k] = l1[j]
    k = k + 1
    j = j+1
print(l3)
