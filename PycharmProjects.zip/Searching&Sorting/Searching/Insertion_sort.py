class sorting():
    def insertionSort(self,alist):
        for index in range(1, len(alist)):
            currentvalue = alist[index]
            position = index
            print("Value",currentvalue,"Position:",position)

            while position > 0 and alist[position - 1] > currentvalue:
                alist[position] = alist[position - 1]
                position = position - 1

            alist[position] = currentvalue
        return alist

ar = [4,2,5,3,12,4,56,2]
s1 = sorting()
    print(s1.insertionSort(ar))