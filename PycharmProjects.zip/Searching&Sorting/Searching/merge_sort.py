class sorting(object):
    def merge_sort(self,array):
        if len(array)>1:
            mid = len(array)//2
            leftarray = array[:mid]
            rightarray = array[mid:]

            i = 0
            j = 0
            k = 0
            while i < len(leftarray) and j < len(rightarray):
                if leftarray[i]<rightarray[j]:
                    array[k] = leftarray[i]
                    k = k+1
                    i = i+1
                else:
                    array[k] = rightarray[j]
                    k = k +1
                    j = j+1

            while i<len(leftarray):
                array[k] = leftarray[i]
                i = i +1
                k = k +1

            while j<len(rightarray):
                array[k] = rightarray[j]
                j = j+1
                k = k+1
        return array

ar = [1,2,5,3,12,4,56,2]

s1 = sorting()
print(s1.merge_sort(ar))