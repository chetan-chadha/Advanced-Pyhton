# from Searching import Bubble_Sort
# arr = [1,5,2,3]
# s1 = Bubble_Sort.sorting()
# s1.bubble_sort(arr)
class sorting(object):
    def selection_sort(self,arr):
        for x in range(len(arr)-1,0,-1):
            positionofmax = 0
            for y in range(1,x+1):
                if arr[y] > arr[positionofmax]:
                    positionofmax = y

            arr[x],arr[positionofmax] = arr[positionofmax],arr[x]
        return arr
ar = [1,2,5,3,12,4,56,2]
s1 = sorting()
print(s1.selection_sort(ar))