def reverse_str(string):
    if len(string)==1:
        return string[0]
    else:
        return reverse_str(string[1:]) + string[0]

print(reverse_str("chetan"))