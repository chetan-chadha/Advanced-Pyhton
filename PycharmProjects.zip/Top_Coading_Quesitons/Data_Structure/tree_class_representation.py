class Tree():
    def __init__(self,value):
        self.root = value
        self.leftNode = None
        self.rightNode = None
    def insertLeft(self,newNode):
        if self.leftNode == None:
            self.leftNode = Tree(newNode)
        else:
            t = self.leftNode
            self.leftNode = Tree(newNode)
            self.leftNode.leftNode = t
    def insertRight(self,newNode):
        if self.rightNode == None:
            self.rightNode = Tree(newNode)
        else:
            t = Tree(newNode)
            t.rightNode = self.rightNode
            self.rightNode = t
    def getRightChild(self):
        return self.rightNode
    def getLeftChild(self):
        return self.leftNode
    def getRootVal(self):
        return self.root
    def setRootVal(self,value):
        self.root = value

# r = Tree('a')
# print(r.getRootVal())
# print(r.getLeftChild())
# r.insertLeft('b')
# print(r.getLeftChild())
# print(r.getLeftChild().getRootVal())
# r.insertRight('c')
# print(r.getRightChild())
# print(r.getRightChild().getRootVal())
# r.getRightChild().setRootVal('hello')
# print(r.getRightChild().getRootVal())