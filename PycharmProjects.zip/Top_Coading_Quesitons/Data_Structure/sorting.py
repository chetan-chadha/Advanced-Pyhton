alist = [54,11,26,93,17,77,31,44,55,20]
def bubble_sort(unsorted):
    for i in range(len(unsorted)-1,0,-1):
        for j in range(i):
            if unsorted[j]>unsorted[j+1]:
                unsorted[j],unsorted[j+1] = unsorted[j+1],unsorted[j]

    return unsorted
def selection_sort(unsorted):
    for i in range(len(unsorted)-1,0,-1):
        max = 0
        for j in range(1,i+1):
            if unsorted[max]<unsorted[j]:
                max = j
        unsorted[max],unsorted[i] = unsorted[i],unsorted[max]
        print(unsorted)
    return unsorted
def insertion_sort(unsorted):
    for i in range(len(unsorted)):
        for j in range(i,0,-1):
            if unsorted[j]<unsorted[j-1]:
                unsorted[j], unsorted[j-1] = unsorted[j-1], unsorted[j]
        print(unsorted)
    return unsorted
def insertion_sort_whileloop(unsorted):
    for i in range(1,len(unsorted)):
        currentvalue = unsorted[i]
        position = i
        while position>0 and unsorted[position-1]>currentvalue:
            unsorted[position] = unsorted[position-1]
            position = position -1
        unsorted[position] = currentvalue
    return unsorted
def merge_sort(unsorted):
    if len(unsorted)>1:
        mid = len(unsorted)//2
        lefthalf = merge_sort(unsorted[:mid])
        righthalf = merge_sort(unsorted[mid:])

        i =0
        j = 0
        k = 0
        while i <len(lefthalf) and j <len(righthalf):
                if lefthalf[i]<righthalf[j]:
                     unsorted[k] = lefthalf[i]
                     i = i +1
                else:
                    unsorted[k] = righthalf[j]
                    j = j +1
                k = k+1

        while i < len(lefthalf):
            unsorted[k] = lefthalf[i]
            k = k+1
            i = i +1

        while j < len(righthalf):
            unsorted[k] = righthalf[i]
            k = k+1
            j = j+1
    return unsorted

def quick_sort(unsorted):
    quick_sort_helper(unsorted,0,len(unsorted))

def quick_sort_helper(unsorted,start,last):
    if first<last:
        splitpoint = partition(unsorted,start,last)
        quick_sort_helper(unsorted,start,splitpoint-1)
        quick_sort_helper(unsorted,splitpoint+1,last)

def partition(unsorted,start,last)
    pivot



# print(bubble_sort(alist))
# print(selection_sort(alist))
# print(insertion_sort(alist))
# print(insertion_sort_whileloop(alist))
print(merge_sort(alist))