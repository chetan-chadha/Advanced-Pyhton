from Data_Structure.Stack import Stack
def Devideby2(num):
    numbr = Stack()
    string = ""
    while num>0:
        rem = num%2
        numbr.push(rem)
        num = num//2
    while numbr.isEmpty()!=True:
        string = string + str(numbr.pop())
    return string
def main():
    number = int(input("Enter Number for converting"))
    binary = Devideby2(number)
    print(int(binary))
if __name__ == '__main__':
    main()