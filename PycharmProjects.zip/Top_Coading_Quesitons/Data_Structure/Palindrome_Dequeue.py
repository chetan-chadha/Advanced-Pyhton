from Data_Structure.Dequeue import Deque
def palindrome_check(string):
    chardeque = Deque()
    for ch in string:
        chardeque.addFront(ch)

    while chardeque.size()>1:
        first = chardeque.removeFront()
        last = chardeque.removeRear()
        if first!=last:
            return False
    return True

print(palindrome_check("rasar"))