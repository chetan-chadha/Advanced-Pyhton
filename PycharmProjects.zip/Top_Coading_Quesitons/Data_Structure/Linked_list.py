class Node:
    def __init__(self,item):
        self.data = item
        self.next = None
    def getData(self):
        return self.data
    def setData(self,item):
        self.data = item
    def getNext(self):
        return self.next
    def setNext(self,next):
        self.next = next
class UnorderedList():
    def __init__(self):
        self.head = None
    def isEmpty(self):
        return self.head == None
    def add(self,item):
        temp = Node(item)
        temp.setNext(self.head)
        self.head = temp
    def size(self):
        current = self.head
        count = 0
        print(current.getData())
        while current != None:
            count +=1
            current = current.getNext()

        return count
    def search(self,item):
        current = self.head
        while current != None:
            print(current.getData())
            if current.getData() == item:
                return True
            else:
                current = current.getNext()

        return False
    def remove(self,item):
        current = self.head
        previous = None
        found = False
        while not found:
            if current.getData()==item:
                found = True
            else:
                previous = current
                current = current.getNext()

        if previous == None:
            self.head = current.getNext()
        else:
            previous.setNext(current.getNext())
    def append(self,item):
        current = self.head
        while current.getNext() != None:
            current = current.getNext()
        temp = Node(item)
        current.setNext(temp)

mylist = UnorderedList()

mylist.add(31)
mylist.add(77)
mylist.add(17)
mylist.add(93)
mylist.add(26)
mylist.add(54)
mylist.append(45)
mylist.search(900)
# print(mylist.size())
# print(mylist.search(93))
# print(mylist.search(100))
#
# mylist.add(100)
# print(mylist.search(100))
# print(mylist.size())
#
# mylist.remove(54)
# print(mylist.size())
# mylist.remove(93)
# print(mylist.size())
# mylist.remove(31)
# print(mylist.size())
# mylist.append(93)
# print(mylist.search(93))
