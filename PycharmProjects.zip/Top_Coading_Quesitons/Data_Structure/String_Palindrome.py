import re
def reverse_string(string):
    if len(string)==1:
        return string[0]
    else:
        return reverse_string(string[1:]) + string[0]
def string_palindrome(string):
    stringn = string.lower()
    stringnew = re.sub('[^0-9a-zA-Z]+','',stringn)
    reverse = reverse_string(stringnew)
    if stringnew == reverse:
        return True
    else:
        return False

print(string_palindrome("Able was I ere I saw Elba"))
