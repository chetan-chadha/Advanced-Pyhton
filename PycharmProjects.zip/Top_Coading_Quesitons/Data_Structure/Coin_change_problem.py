def min_change_coin(coin_list,amount,calculated_min):
    min = amount
    if calculated_min[amount]>0:
        return calculated_min[amount]
    elif amount in coin_list:
        calculated_min[amount] = 1
        return 1
    else:
        for x in [c for c in coin_list if c <=amount]:
            num = 1 + min_change_coin(coin_list,amount-x,calculated_min)
            if num<min:
                min = num
                calculated_min[amount] = min
    return min




min = min_change_coin([1,2,5,10,30],49,[0]*66)
print(min)