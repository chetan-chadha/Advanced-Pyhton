from Data_Structure.Stack import Stack
def balanced_paranthesis(string):
    s = Stack()
    if len(string)%2 != 0:
        return False
    else:
        for x in string:
            if x == '(':
                s.push(x)
            elif x == ')':
                if s.isEmpty()==True:
                    return False
                else:
                    s.pop()
        if s.isEmpty() == True:
            return True
        else:
            return False
def balanced_paranthesis_all(string):
    if len(string)%2 != 0:
        return False
    else:
        p1 = Stack()
        p2 = Stack()
        p3 = Stack()
        for x in string:
            if x == '(':
                p1.push(x)
            elif x == '[':
                p2.push(x)
            elif x == '{':
                p3.push(x)
            elif x == ')':
                if p1.isEmpty()==True:
                    return False
                else:
                    p1.pop()
            elif x == ']':
                if p2.isEmpty()==True:
                    return False
                else:
                    p2.pop()
            elif x == '}':
                if p3.isEmpty()==True:
                    return False
                else:
                    p3.pop()
        if p1.isEmpty()==p2.isEmpty()==p3.isEmpty()==True:
            return True
        else:
            return False
def balanced_parenthesis_final(string):
    s = Stack()
    dic = dict()
    dic[')'] = '('
    dic[']'] = '['
    dic['}'] = '{'
    for x in string:
        if x in ['(','[','{']:
            s.push(x)
        elif x in [')',']','}']:
            print(dic[x],s.peek())
            if dic[x] == s.peek():
                s.pop()
            else:
                return False
    if s.isEmpty()==True:
        return True
    else:
        return False

def main():
    parenthesis = input("Enter String")
    print(balanced_parenthesis_final(parenthesis))

if __name__ == '__main__':
    main()
