import random
from Data_Structure.Queue import Queue
class Printer():
    def __init__(self,prm):
        self.pagerate = prm
        self.timeremaining = 0
        self.currenttask = None

    def check_busy(self):
        if self.currenttask == None:
            return False
        else:
            return True
    def startNext(self,newTask):
        self.currenttask = newTask
        self.timeremaining = newTask.get_pages()*60/self.pagerate
    def tick(self):
        if self.currenttask != None:
            self.timeremaining = self.timeremaining - 1
            if self.timeremaining <= 0:
                self.currenttask = None


class Task():
    def __init__(self,time):
        self.timestamp = time
        self.pages = random.randint(1,20)
    def get_stamp(self):
        return self.timestamp
    def get_pages(self):
        return self.pages
    def wait_time(self,current_time):
        return current_time - self.timestamp

def newPrintTask():
    num = random.randrange(1,181)
    if num == 180:
        return True
    else:
        return False
def simulation(numSeconds,ppm):
    labPrinter = Printer(ppm)
    waitingQueue = Queue()
    waiting_time = list()

    for currentsecond in range(numSeconds):
        if newPrintTask():
            task = Task(currentsecond)
            waitingQueue.enqueue(task)
        if (not labPrinter.check_busy())and (not waitingQueue.isEmpty()):
            nexttask = waitingQueue.dequeue()
            waiting_time.append(nexttask.wait_time(currentsecond))
            labPrinter.startNext(nexttask)
        labPrinter.tick()

    averageWait = sum(waiting_time) / len(waiting_time)
    print("Average Wait %6.2f secs %3d tasks remaining." % (averageWait, waitingQueue.size()))

for i in range(10):
    simulation(3600,5)

