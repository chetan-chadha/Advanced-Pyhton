def preorder(tree):
    if tree:
        print(tree.getRootVal())
        preorder(tree.getLeftChild())
        preorder(tree.getRightChild())
def postorder(tree):
    if tree:
        postorder(tree.getLeftChild())
        postorder(tree.getRightChild())
        print(tree.getRootVal())
def inoder(tree):
    if tree:
        inoder(tree.getLeftChild())
        print(tree.getRootVal())
        inoder(tree.getRightChild())
        