class Hashing():
    def __init__(self):
        self.size = 11
        self.slots = [None]*self.size
        self.data = [None]*self.size
    def hashfunction(self,key):
        return key%self.size
    def rehashfunction(self,oldhash):
        # print((oldhash+1)%self.size)
        return (oldhash+1)%self.size
    def put(self,key,data):
        hashvalue = self.hashfunction(key)
        if self.slots[hashvalue] == None:
            self.slots[hashvalue] =key
            self.data[hashvalue] = data
        else:
            if self.slots[hashvalue] == key:
                self.data[hashvalue] = data
            else:
                newhash = self.rehashfunction(hashvalue)
                while self.slots[newhash] != None and self.slots[newhash] != key:
                    newhash = self.rehashfunction(newhash)
                if self.slots[newhash] == None:
                    self.slots[newhash] = key
                    self.data[newhash] = data
                else:
                    self.data[newhash] = data

    def get(self,key):
        hashvalue = self.hashfunction(key)
        if self.slots[hashvalue] == key:
            return self.data[hashvalue]
        else:
            newhash = self.rehashfunction(hashvalue)
            while self.slots[newhash] != key:
                newhash = self.rehashfunction(newhash)
            return self.data[newhash]
    def __getitem__(self, key):
        return self.get(key)
    def __setitem__(self,key,data):
        self.put(key,data)

H = Hashing()
H[54]="cat"
H[26]="dog"
H[93]="lion"
H[17]="tiger"
H[77]="bird"
H[31]="cow"
H[44]="goat"
H[56]="pig"
H[20]="chicken"
print(H.slots)
print(H.data)

print(H[20])
print(H[17])
H[20]='duck'
print(H[20])
print(H[99])
