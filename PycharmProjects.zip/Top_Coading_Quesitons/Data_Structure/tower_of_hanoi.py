from Data_Structure.Stack import Stack
def tower_of_hanoi(height,frompole,topole,withpole):
    if height == 0:
        topole.push(frompole.pop())
        print(topole,frompole)
    else:
        tower_of_hanoi(height-1,frompole,withpole,topole)
        topole.push(frompole.pop())
        print(topole,frompole)
        tower_of_hanoi(height-1,withpole,topole,frompole)

def moveDisk(src, dest):
    dest.push(src.pop())

def moveTower(n, src, spare, dest):
    if n == 0:
        moveDisk(src, dest)
    else:
        moveTower(n - 1, src, dest, spare)
        moveDisk(src, dest)
        moveTower(n - 1, spare, src, dest)
def main():
    frompole = Stack()
    topole = Stack()
    withpole = Stack()
    frompole.push(5)
    frompole.push(6)
    frompole.push(7)
    print(frompole.size())
    moveTower(frompole.size(),frompole,topole,withpole)


main()
