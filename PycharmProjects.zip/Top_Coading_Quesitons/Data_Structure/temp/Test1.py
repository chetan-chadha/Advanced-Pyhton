def sumofnum(num1,num2,lst):
    lst.append(num1+num2)
    return
def findsum(no1,no2):
    lst = [0]
    sumofnum(no1,no2,lst)
    return lst

print(findsum(3,4))