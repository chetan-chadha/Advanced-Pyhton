def binary_search_finder(arr,num,closest_no):
    mid = len(arr)//2
    temp = abs(arr[mid]-num)
    # print(temp,mid,closest_no)
    if temp == 0:
        return temp+num
    elif temp>=closest_no-num:
        # print(closest_no-num)
        return closest_no
    else:
        closest_no = arr[mid]
        if num < arr[mid]:
            return binary_search_finder(arr[:mid],num,closest_no)
        elif num > arr[mid]:
            return binary_search_finder(arr[mid:],num,closest_no)


def main():
    array = list(map(int,input("Enter Array").split()))
    no = int(input("Enter Number whoes Nearest one need to find"))
    number = binary_search_finder(array,no,max(array))
    print(number)

if __name__ == '__main__':
    main()