len_num_array,max_length = map(int,input().split())
num_array = list(map(int,input().split()))
lst = set()
def bitwiseor(lst):
    bit_or = 0
    for x in lst:
        bit_or = bit_or | x
    # print(bit_or)
    return bit_or
for x in range(1,max_length+1):
    for y in range(len(num_array)-x+1):
        print(num_array[y:y+x])
        lst.add(bitwiseor(num_array[y:y+x]))
print(len(lst))