import numpy as np
data,test_case = map(int,input().split())
lst = list()
ndarray = list()
for x in data:
    ndarray = np.append(list(map(int,input().split())))
lst = list(ndarray.sum(axis=0))
for x in test_case:
    test = int(input())
    if test in lst:
        print("YES")
    else:
        print("NO")


