length,testcases = map(int,input().split())
a = list(map(int,input().split()))
for x in range(testcases):
    case = list(map(int,input().split()))
    if case[0] == 1:
        a[case[1]] = a[case[2]]
    else:
        sum = 0
        for x in range(case[1],case[2]+1):
            sum = sum + a[x]
        print(sum)
