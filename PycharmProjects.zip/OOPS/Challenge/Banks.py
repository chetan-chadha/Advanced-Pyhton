from Challenge import customer
class Bank(object):
    __id = 0
    __name = ""
    __asset = 0
    customers = ""

    def __init__(self,count):
        print("Enter Bank",count,"details")
        self.id =  int(input("Enter Bank ID"))
        self.name = input("Enter Name of Bank")
        self.no_of_customer = int(input("Enter No of Customers"))
        self.assets = int(input("Enter Assets"))

    def sample(self) :
        self.customers = list()
        for x in range(self.no_of_customer):
            self.customers.append(customer.Customer(x + 1))

    def creating_customers(self,count):
        for x in range(count):
            self.customers.append(customer.Customer(x+1))

    @property
    def id(self):
        # print("School_name = ",self.__school.getval())
        return self.__id
    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        # print("School_name = ",self.__school.getval())
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def assets(self):
        # print("School_name = ",self.__school.getval())
        return self.__assets

    @assets.setter
    def assets(self, value):
        self.__assets = value

b1 = Bank(1)
b1.id = 123
print(b1.id)