from Challenge import Banks
from com.mindtree.oops import Sorting_Objects
max = 0
no_of_banks = int(input("Enter No of Banks"))
banks = list()
for x in range(no_of_banks):

    banks.append(Banks.Bank(x+1))

for x in range(3):
    Case = int(input("Enter Case No"))
    if Case == 1:
        for x in banks:
            x.sample()
            print("___________________________")
            print(x.id,x.name,x.assets,)
            print("____customer______")
            for y in x.customers:
                print(y.id,y.name,y.gender)
    elif Case == 2:
        for x in range(len(banks)-1):
            if banks[x].assets>banks[x+1].assets:
                maxe = banks[x]
            else:
                maxe = banks[x+1]
        print(maxe.id,maxe.assets,maxe.name)

    elif Case == 3:
        count = 0
        nameSearch = input("enter the name")
        for x in range(len(banks)):
            if banks[x].name == nameSearch:
                maxe = banks[x]
                print("Bank Found",banks[x].id)
                count = 1
                break
        if count==0:
            print("No such Bank")

