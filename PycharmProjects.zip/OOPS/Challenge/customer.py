class Customer(object):
    __id = 0
    __name = ""
    __gender = ""
    def __init__(self,count):
        print("Enter Customer",count,"details")
        self.id = int(input("Enter ID"))
        self.name = input("Enter Name")
        self.gender = input("Enter Gender")

    @property
    def id(self):
        # print("School_name = ",self.__school.getval())
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        # print("School_name = ",self.__school.getval())
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def gender(self):
        # print("School_name = ",self.__school.getval())
        return self.__gender

    @gender.setter
    def gender(self, value):
        self.__gender = value
