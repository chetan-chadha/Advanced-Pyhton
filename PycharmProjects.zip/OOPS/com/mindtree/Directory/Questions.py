li = (1,2,3,4)
l2 = ("chetan","Chadha")
l3 = (7,8,9)
l4 = li + l2
print(l4)
dic = {1:'One','two':'numberTwo',3:'Three'}

for key,value in dic.items():
    print(key,value)


