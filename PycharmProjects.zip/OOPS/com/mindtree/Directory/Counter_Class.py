class Counter:
    def __init__(self,limit):
        self.limit = limit
        self.__iter__()
    def __iter__(self):
        self.n = 0
        return self
    def __next__(self):
        result = self.n + 3
        if result < self.limit:
            self.n = self.n +3
            return result
        else:
            raise StopIteration

c1 = Counter(10)

print(c1.__next__())
print(c1.__next__())
print(c1.__next__())
print(c1.__next__())
