import threading
import time

def func1():
    for x in range(4):
        print(x)
        time.sleep(1)
def func2():
    for x in range(5):
        print("second")
        time.sleep(1)
def func3():
    for x in range(2):
        print("third")
        time.sleep(1)

t1 = threading.Thread(target=func1)
t2 = threading.Thread(target=func2)
t3 = threading.Thread(target=func3)

t1.start()
t1.join()
t2.start()
# time.sleep(1)
t2.join()
t3.start()

