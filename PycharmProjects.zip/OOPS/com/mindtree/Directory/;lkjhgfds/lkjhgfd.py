from com.mindtree.Directory.Campus import Campus
class