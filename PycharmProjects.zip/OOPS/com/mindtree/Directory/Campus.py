# from com.mindtree.Directory.Mindtree import Mindtree
from com.mindtree.Directory.Mindtree import Mindtree
class Campus(Mindtree):
    __location = ""
    __count = 0
    def __init__(self,location,count,country,totalcount):
        Mindtree.__init__(self,country,totalcount)
        self.location = location
        self.count = count

    @property
    def location(self):
        return self.__location
    @location.setter
    def location(self,value):
        self.__location = value

    @property
    def count(self):
        return self.__count

    @count.setter
    def count(self, value):
        self.__count = value

c1 = Campus('india',34,"sf",435)
print(c1.location)
c1.location = "asfdfa"