from com.mindtree.Directory.Campus import Campus
object_count = int(input("Enter Total no of campus"))
object_list = list()
for x in range(object_count):
    country = input("Enter Country")
    totalcount = input("Enter Total count")
    location = input("Enter Location")
    count = input("Enter count")
    object_list.append(Campus(location,count,country,totalcount))

Location_array = [x.location for x in object_list]
print(Location_array)

import math
import numpy
import pandas