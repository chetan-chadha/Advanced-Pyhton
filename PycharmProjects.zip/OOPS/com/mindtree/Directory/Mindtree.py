class Mindtree(object):
    __country = ""#Private
    _country1 = ""#protected
    __total_count = int()

    def __init__(self,country,count):
        self.country = "India"
        self.total_count = count

    @property
    def country(self):
        return self.__country
    @country.setter
    def country(self,value):
        self.__country = value


    @property
    def total_count(self):
        return self.__total_count

    @total_count.setter
    def total_count(self, value):
        self.__total_count = value

    def hello(self):
        return self.__country

    def setCountry(self,value):
        self.__country=value

    def getCountry(self):
        return self.__country
