class Function:
    var = "dsjhaf"
    def __init__(self):
        self.__hello = "hello"
    def __str__(self):
        return self.var

f1 = Function()
f1.__hello = "main"
Function.var = "hello"
f2 = Function()
print(f2)

