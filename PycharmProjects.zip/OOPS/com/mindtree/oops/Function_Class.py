class Functions:
    def Inc_Middle(self,array, size):
        return (array + 10 ** (size // 2))

    def convert(self,list):
        # Converting integer list to string list
        s = [str(i) for i in list]
        # Join list items using join()
        res = int("".join(s))
        return (res)

    def InterchangingDigits(self,array):
        temp = array[0]
        array[0] = array[1]
        array[1] = temp
        return array

    def checkmin(self,lst):
        min = lst[0]
        for i in lst:
            if i < min:
                min = i
        return min
    def printsomething(self,data):
        return data + 2

class main(Functions):
    totalNumber = int(input())
    size = int(input())
    lst = list(map(int, input().split()))

    for i in range(totalNumber):
        D_Manipulation = Functions()
        print(lst)
        lst[i] = D_Manipulation.Inc_Middle(lst[i], size)
        print(lst)
        lst[i] = [int(i) for i in str(lst[i])]
        print(lst)
        lst[i] = D_Manipulation.InterchangingDigits(lst[i])
        lst[i] = D_Manipulation.convert(lst[i])
    print(lst)
    min = D_Manipulation.checkmin(lst)
    print(str(min)[2] if len(str(min)) > 2  else str(min)[1])
if __name__ == '__main__':
    main()