class Student:
    __id = ''
    __name = ''
    __marks = 0
    def __init__(self,val):
        print("Enter Student ID of ",val," :")
        self.id  = input()
        print("Enter Student Name of ", val, " :")
        self.name  = input()
        print("Enter Student marks of ", val, " :")
        self.marks  = list(map(int,input().split()))

    @property
    def id(self):
        return self.__id
    @id.setter
    def id(self,val):
        self.__id = val

    @property
    def name(self):
        # print("School_name = ",self.__school.getval())
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def marks(self):
        # print("School_name = ",self.__school.getval())
        return self.__marks

    @marks.setter
    def marks(self, value):
        for x in value:
            self.__marks = self.__marks + x

