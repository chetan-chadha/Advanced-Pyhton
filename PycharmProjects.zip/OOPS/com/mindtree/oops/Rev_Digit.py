def Inc_Middle(array,size):
    return (array + 10**(size//2))
def convert(list):
    # Converting integer list to string list
    s = [str(i) for i in list]
    # Join list items using join()
    res = int("".join(s))
    return (res)
def interchangingDigits(array):
    temp = array[0]
    array[0] = array[1]
    array[1] = temp
def checkmin(lst):
    min = lst[0]
    for i in lst:
        if i < min:
            min = i
    return min

def main():
    totalNumber = int(input())
    size = int(input())
    lst = list(map(int,input().split()))

    for i in range(totalNumber):
        print(lst)
        lst[i] = Inc_Middle(lst[i],size)
        print(lst)
        lst[i] = [int(i) for i in str(lst[i])]
        print(lst)
        interchangingDigits(lst[i])
        lst[i] = convert(lst[i])
    print(lst)
    min = checkmin(lst)
    print(str(min)[2])
if __name__ == '__main__':
    main()