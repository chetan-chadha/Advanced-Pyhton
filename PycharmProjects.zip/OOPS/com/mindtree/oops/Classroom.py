class Classroom():
    __id = ""
    __name = ""
    __capacity = ""
    def __init__(self):
        self.ids = input("Enter Classroom ID ")
        self.name = input("Enter Classroom Name ")
        self.capacity = input("Enter Classroom Capacity ")
    @property
    def ids(self):
        return self.__id

    @ids.setter
    def ids(self, value):
        self.__id = value

    @property
    def name(self):
        # print("School_name = ",self.__school.getval())
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def capacity(self):
        # print("School_name = ",self.__school.getval())
        return self.__capacity

    @capacity.setter
    def capacity(self, value):
        self.__capacity = value

