from com.mindtree.oops import Student
class teacher(object):
    __id = ""
    __name = ""
    __student = []

    def __init__(self):
        # self.id = input("Enter Teacher Id ")
        # self.name = input("Enter Teacher Name ")
        self.count = int(input("Enter Number of Students"))
        for x in range(self.count):
            self.student.append(Student.Student(x+1))

    @property
    def id(self):
        # print("School_name = ",self.__school.getval())
        return self.__id

    @id.setter
    def id(self, value):
        print("setter")
        self.__id = value

    @property
    def name(self):
        # print("School_name = ",self.__school.getval())
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value


    @property
    def student(self):
        # print("School_name = ",self.__school.getval())
        return self.__student

    @student.setter
    def student(self, value):
        self.__student = value




