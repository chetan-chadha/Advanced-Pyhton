from com.mindtree.oops import Classroom as ch
class School(ch.Classroom):
    __name = ""
    __classroom = ""
    __id = ""
    def __init__(self):
        self.id = input("Enter School ID ")
        self.name = input("Enter School Name ")
        self.classroom = ch.Classroom()

    def getval(self):
        print(self.capacity)

    @property
    def id(self):
        # print("School_name = ",self.__school.getval())
        return self.__id

    @id.setter
    def id(self, value):
        self.__id = value

    @property
    def name(self):
        # print("School_name = ",self.__school.getval())
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def classroom(self):
        # print("School_name = ",self.__school.getval())
        return self.__classroom

    @classroom.setter
    def classroom(self, value):
        self.__classroom = value