from com.mindtree.oops import School
from com.mindtree.oops import Student
class Teacher(object):
    __id = ""
    __name = ""
    __student = []
    __school = ""
    def __init__(self):
        self.id = input("Enter Teacher Id ")
        self.name = input("Enter Teacher Name ")
        self.school = School.School()
        for x in range(3):
            self.student.append(Student.Student())

    @property
    def id(self):
        # print("School_name = ",self.__school.getval())
        return self.__id
    @id.setter
    def id(self, value):
        print("setter")
        self.__id = value

    @property
    def name(self):
        # print("School_name = ",self.__school.getval())
        return self.__name
    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def school(self):
        # print("School_name = ",self.__school.getval())
        return self.__school

    @school.setter
    def school(self, value):
        self.__school = value

    @property
    def student(self):
        # print("School_name = ",self.__school.getval())
        return self.__student

    @student.setter
    def student(self, value):
        self.__student = value

