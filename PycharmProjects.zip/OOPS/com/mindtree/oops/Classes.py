# from com.mindtree.oops import Teacher
from com.mindtree.oops import Teacher
t1 = Teacher.Teacher()
print(t1.school.name)
print(t1.school.classroom.name)
print(t1.id)
print(t1.student[0].name)