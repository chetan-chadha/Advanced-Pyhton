class sorting(object):

    def insertionSort(self,alist, count):
        for index in range(1, count):
            currentvalue = alist[index].name
            position = index
            currentindex = alist[index]

            while position > 0 and alist[position - 1].name > currentvalue:
                alist[position] = alist[position - 1]
                position = position - 1
            alist[position] = currentindex
        for x in range(len(alist)-1,-1,-1):
            print(alist[x].id, alist[x].name,alist[x].marks)

    def bubble_sort_recurrsion(self,array,length):
        if length>0:
            print(length)
            for y in range(length-1):
                if array[y].gender > array[y + 1].gender:
                    array[y + 1], array[y] = array[y], array[y + 1]
            return self.bubble_sort_recurrsion(array,length-1)
        else:
            for x in array:
                print(x.id, x.name)