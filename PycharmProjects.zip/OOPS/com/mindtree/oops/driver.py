from com.mindtree.oops import strict_teacher
from com.mindtree.oops import Sorting_Objects


s1 = strict_teacher.teacher()
sorting = Sorting_Objects.sorting()
sorting.insertionSort(s1.student,s1.count)
# sorting.bubble_sort_recurrsion(s1.student,s1.count)