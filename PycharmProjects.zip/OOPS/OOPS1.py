class Campus_mind:
    companyname = "Mindtree"
    def __init__(self,name,MID,Track,Salary):
        self.name = name
        self.MID = MID
        self.Track = Track
        self.Salary = Salary
    def increaseSalary(self):
        self.Salary = self.Salary*2
    pass
c1 = Campus_mind("chetan","M1050949","Python",2345)
c2 = Campus_mind("ABC","adf","pythonn",2323)
c2.anything = "anything"
print(c2.__dict__)
print(help(c2))
c1.companyname = "Google"
print(c2.companyname)
print(c2.Salary)
Campus_mind.increaseSalary(c2)
print(c2.Salary)
print(c1.name)
print(c1.companyname)