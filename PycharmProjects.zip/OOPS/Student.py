import Address


class Student(object):
    __sid = int()
    __sname = ""
    __gender = ""
    __mobnumber = []
    __address = []
    address = ",,,,,"
    def __init__(self,id=None,name=None,gender = None,mobilenumber=None,address = None):
        self.__id = id
        self.__name = name
        self.__gender = gender
        self.__mobnumber = mobilenumber
        self.__address = address

    @property
    def id(self):
        return self.__sid

    @id.setter
    def id(self, val):
        self.__sid = val

    @property
    def name(self):
        # print("School_name = ",self.__school.getval())
        return self.__sname

    @name.setter
    def name(self, value):
        self.__sname = value

    @property
    def gender(self):
        # print("School_name = ",self.__school.getval())
        return self.__gender

    @gender.setter
    def gender(self, value):
        self.__gender = value

    @property
    def mobnumber(self):
        # print("School_name = ",self.__school.getval())
        return self.__mobnumber

    @mobnumber.setter
    def mobnumber(self, value):
        self.__mobnumber = value

    @property
    def address(self):
        # print("School_name = ",self.__school.getval())
        return self.__address

    @address.setter
    def address(self, value):
        self.__address = value



