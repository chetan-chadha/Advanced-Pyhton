class Address(object):
    __type = ""
    __street = ""
    __city = ""
    __dist = ""
    __state = ""
    __pin = 0

    def __init__(self,type_= None, street = None, city = None, dist = None, state = None, pin = None):
        self.__type = type_
        self.__street = street
        self.__city = city
        self.__dist = dist
        self.__state = state
        self.__pin = pin

    @property
    def type(self):
        # print("School_name = ",self.__school.getval())
        return self.__type

    @type.setter
    def type(self, value):
        self.__type = value

    @property
    def street(self):
        # print("School_name = ",self.__school.getval())
        return self.__street

    @street.setter
    def street(self, value):
        self.__street = value

    @property
    def city(self):
        # print("School_name = ",self.__school.getval())
        return self.__city

    @city.setter
    def city(self, value):
        self.__city = value

    @property
    def dist(self):
        # print("School_name = ",self.__school.getval())
        return self.__dist

    @dist.setter
    def dist(self, value):
        self.__dist = value

    @property
    def state(self):
        # print("School_name = ",self.__school.getval())
        return self.__state

    @state.setter
    def state(self, value):
        self.__state = value

    @property
    def pin(self):
        # print("School_name = ",self.__school.getval())
        return self.__pin

    @pin.setter
    def pin(self, value):
        self.__pin = value