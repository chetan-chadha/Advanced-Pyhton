class Campus_Minds(object):
    def __init__(self,name = None,MID = None,Track = None,salary = None):
        self.name = name
        self.MID = MID
        self.Track = Track;
        self.salary = salary;

    def increasesalary(self):
        self.salary = self.salary * 2;


ch = Campus_Minds("chetan","M324","dfcas",23)
print(ch.salary)
ch.increasesalary()
ch.value = "hello"
print(ch.__dict__)
print(ch.salary)