import Student
import Address
from com.mindtree.oops import Sorting_Objects
def creating_address():
    adrslist = []
    for x in range(1):
        type = input("Enter type")
        street = input("Enter Street")
        city = input("Enter City")
        dist = input("Enter Dist")
        state = input("Enter state")
        pin = input("Enter pin")
        constructor = input("Wna Call constuctor")
        if constructor == 1:
            s1 = Address.Address(type,street,city,dist,state,pin)
        else:
            s1 = Address.Address()
            s1.type = type
            s1.city = city
            s1.street = street
            s1.dist = dist
            s1.state = state
            s1.pin = pin
        adrslist.append(s1)
    return adrslist
def creating_student():
    sid = int(input("Enter SID"))
    sname = input("Enter Sname")
    gender = input("Enter Gender")
    mobileno = list()
    no_of_mobile = int(input("No of phones you are having"))
    for x in range(no_of_mobile):
        try:
            mobile = int(input("Enter Mobile No"))
            if len(str(mobile)) < 10:
                raise ValueError
        except:
            print("Enter Correct No")
        else:
            print("hello")
            mobileno.append(int(mobile))

    constructor = input("Wna Call constuctor")
    if constructor == 1:
        stu_obj = Student.Student(sid, sname, gender, mobileno, creating_address())
    else:
        stu_obj = Student.Student()
        stu_obj.id = sid
        stu_obj.name = sname
        stu_obj.gender = gender
        stu_obj.address = creating_address()
        stu_obj.mobnumber = mobileno
    return stu_obj

def main():
    students_count = int(input("Enter no of students"))
    studentsobj = list()
    for x in range(students_count):
        studentsobj.append(creating_student())
    for x in range(students_count):
        print(studentsobj[x].id,studentsobj[x].name,studentsobj[x].gender,studentsobj[x].mobnumber,end=" ")
        # for y in range(2):
        #     print(studentsobj[x].address[y].type,studentsobj[x].address[y].street,studentsobj[x].address[y].city,studentsobj[x].address[y].pin)
    userstate = input("Enter State")
    for x in range(students_count):
        if studentsobj[x].address[0].state == userstate:
            print(studentsobj[x].name)
    s2 = Sorting_Objects.sorting()
    s2.insertionSort(studentsobj,len(studentsobj))
    for x in range(students_count):
        print(studentsobj[x].id,studentsobj[x].name,studentsobj[x].gender,studentsobj[x].mobnumber,end=" ")
        for y in range(2):
            print(studentsobj[x].address[y].type,studentsobj[x].address[y].street,studentsobj[x].address[y].city,studentsobj[x].address[y].pin)

    s2.bubble_sort_recurrsion(studentsobj, len(studentsobj))
    for x in range(students_count):
        print(studentsobj[x].id, studentsobj[x].name, studentsobj[x].gender, studentsobj[x].mobnumber, end=" ")
        for y in range(2):
            print(studentsobj[x].address[y].type, studentsobj[x].address[y].street, studentsobj[x].address[y].city,
                  studentsobj[x].address[y].pin)


if __name__ == '__main__':
    main()