from Birds import Bird
from import_fun import print_values
class Pigeon(Bird):
    _age = int()
    __height = int()
    def __init__(self,name = "pigeon",height = 0,age = 0):
        Bird.__init__(self,name,height,age)
        self.height = height
        self.age = age
    @property
    def height(self):
        return self.__height
    @height.setter
    def height(self,value):
        self.__height = value
    @property
    def age(self):
        return self._age
    @age.setter
    def age(self,value):
        self._age = value
    def fly(self):
        print("I will not able to FLy")

