def func(a):
    print("hello",a)

def print_values(arr):
    if len(arr)==1:
        print(arr.name, arr.height, arr.age)
    else:
        for x in arr:
            print(x.name,x.height,x.age)