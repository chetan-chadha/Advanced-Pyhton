from function import print_values
from abc import ABC,abstractmethod
class Bird(ABC):
    name = ""
    age = int()
    # def __init__(self,name,height,age):
    #     self.name = name
    #     self.age = age
    #     self.height = height
    @abstractmethod
    def fly(self):
        pass
    def fly(self):
        print("I will able to fly")
    def create_obj(self,len):
        lst = list()
        for x in range(1, len):
            lst.append(Bird(name = "parrot"+str(x),height=4 + x, age=5 + x))
        print_values(lst)
class pigeon(Bird):
    # def fly(self):
    #     print("I will able to fly")
    pass
# obj1 = Bird("afsd",34,23)
# obj1.create_obj(5)

p1 = pigeon()
p1.fly()