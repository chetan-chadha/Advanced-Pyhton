from function import func,print_values
func(4)