from Pigeon import Pigeon,Bird
from import_fun import print_values
#main function starts from here
a = 6
# def main():
lst = list()
for x in range(1,6):
    lst.append(Pigeon(height=4+x,age = 5+x))

c1 = Bird("parrot",5,6)
c1.create_obj(5)
# print_values(newlist)
#
# if __name__ == '__main__':
#     main()