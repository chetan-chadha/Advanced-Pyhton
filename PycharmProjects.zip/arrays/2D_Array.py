from array import *
t = array('i',[1,2,3,4,5,6])
t1 = [1,2,3]
print(type(t),type(t1))
t[1] = t1