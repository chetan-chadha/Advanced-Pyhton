def square_of_sum(x = 4,y = 3):
    result = (x+y)**2
    print('(',x,'+', y,')','^',2,'=',result)

square_of_sum()






